from flask import Flask,request,redirect,url_for,render_template_string,session
from flask_sqlalchemy import SQLAlchemy

app=Flask(__name__)
app.secret_key="abc"
app.config["SQLALCHEMY_DATABASE_URI"]="sqlite:///u.db"
db=SQLAlchemy(app)

class U(db.Model):
    id=db.Column(db.Integer,primary_key=True)
    a=db.Column(db.String(100),unique=True,nullable=False)
    b=db.Column(db.String(100),nullable=False)

@app.route("/")
def x():
    return render_template_string("""
    <h2>Home</h2>
    <a href='/s'>Sign Up</a> | 
    <a href='/l'>Login</a> | 
    <a href='/u'>Users</a>
    """)

@app.route("/s",methods=["GET","POST"])
def s():
    if request.method=="POST":
        a=request.form["username"]
        b=request.form["password"]
        if U.query.filter_by(a=a).first():
            return "exists"
        db.session.add(U(a=a,b=b))
        db.session.commit()
        return redirect(url_for("l"))
    return render_template_string("""
    <h2>Sign Up</h2>
    <form method="POST">
      <input name="username"><br>
      <input type="password" name="password"><br>
      <button>ok</button>
    </form>
    <a href='/'>Back</a>
    """)

@app.route("/l",methods=["GET","POST"])
def l():
    if request.method=="POST":
        a=request.form["username"]
        b=request.form["password"]
        q=U.query.filter_by(a=a,b=b).first()
        if q:
            session["a"]=q.a
            return redirect(url_for("d"))
        return "wrong"
    return render_template_string("""
    <h2>Login</h2>
    <form method="POST">
      <input name="username"><br>
      <input type="password" name="password"><br>
      <button>ok</button>
    </form>
    <a href='/'>Back</a>
    """)

@app.route("/d")
def d():
    if "a" in session:
        return f"<h2>hi {session['a']}</h2><a href='/o'>out</a>"
    return redirect(url_for("l"))

@app.route("/o")
def o():
    session.pop("a",None)
    return redirect(url_for("x"))

@app.route("/u")
def u():
    q=U.query.all()
    z="<br>".join([f"{i.id}. {i.a} - {i.b}" for i in q])
    return f"<h2>Users</h2>{z}<br><a href='/'>Back</a>"

if __name__=="__main__":
    with app.app_context():
        db.create_all()
    app.run(debug=True)
